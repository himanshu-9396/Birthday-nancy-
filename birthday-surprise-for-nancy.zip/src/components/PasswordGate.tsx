import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, Heart, ArrowRight, ShieldCheck, ShieldAlert } from 'lucide-react';

interface PasswordGateProps {
  onUnlock: () => void;
  onGoToGame: () => void;
  initialPassword?: string;
}

export default function PasswordGate({ onUnlock, onGoToGame, initialPassword = '' }: PasswordGateProps) {
  const [password, setPassword] = useState(initialPassword);
  const [error, setError] = useState(false);
  const [shake, setShake] = useState(false);

  // Synchronize when initialPassword changes
  React.useEffect(() => {
    if (initialPassword) {
      setPassword(initialPassword);
    }
  }, [initialPassword]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPw = password.trim().toUpperCase();
    if (cleanPw === '4 JUNE') {
      setError(false);
      onUnlock();
    } else {
      setError(true);
      setShake(true);
      setTimeout(() => setShake(false), 600);
    }
  };

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none overflow-hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ 
          opacity: 1, 
          scale: 1, 
          y: 0,
          x: shake ? [-10, 10, -10, 10, -5, 5, 0] : 0
        }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="relative max-w-sm w-full p-8 rounded-3xl bg-brand-cream/95 border-2 border-brand-grey/85 shadow-[0_22px_60px_rgba(92,75,64,0.12)] flex flex-col items-center gap-6"
        id="password-gate-card"
      >
        <motion.div
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
          className="w-16 h-16 rounded-full bg-brand-cream border border-brand-grey/80 flex items-center justify-center text-brand-brown shadow-sm"
        >
          <Lock size={30} className="animate-pulse" />
        </motion.div>

        <h2 className="font-royal text-xl font-bold text-brand-brown tracking-widest uppercase">
          🔐 Enter Royal Key
        </h2>

        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-4">
          <div className="relative w-full">
            <input
              id="password-input"
              type="text"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (error) setError(false);
              }}
              placeholder="Enter Password..."
              className="w-full px-5 py-3 rounded-xl bg-white border-2 border-brand-grey text-brand-brown font-royal text-center text-lg placeholder-brand-brown/40 font-bold focus:outline-none focus:ring-2 focus:ring-brand-brown/50 focus:border-transparent tracking-widest transition-all uppercase"
            />
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="text-xs font-semibold text-rose-700 font-sans flex items-center justify-center gap-1"
            >
              <ShieldAlert size={14} /> Incorrect golden credentials! Hint: Click link below
            </motion.p>
          )}

          <motion.button
            id="password-submit-btn"
            whileHover={{ scale: 1.02, backgroundColor: '#4A3D35' }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            className="w-full py-3.2 rounded-xl bg-brand-brown text-brand-cream font-bold text-sm tracking-widest shadow-md flex items-center justify-center gap-2 border border-brand-brown cursor-pointer transition-colors"
          >
            SUBMIT KEY <ArrowRight size={18} />
          </motion.button>
        </form>

        <button
          id="btn-get-password"
          onClick={onGoToGame}
          className="text-xs font-semibold text-brand-brown/80 hover:text-brand-brown underline decoration-[#D1CFCB] transition-colors cursor-pointer mt-2 leading-relaxed"
        >
          Don't know password? Play matching hearts!
        </button>
      </motion.div>
    </div>
  );
}
