import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Heart } from 'lucide-react';

interface BirthdayWishesProps {
  onNext: () => void;
}

const letterLines = [
  'Dear Nancy,',
  'May your smile never fade.',
  'May your dreams come true.',
  'May happiness, success, love, and beautiful memories always stay with you.',
  'May every new day bring something wonderful into your life.',
  'Thank you for making the world brighter with your smile.',
  'Happy Birthday ❤️',
];

export default function BirthdayWishes({ onNext }: BirthdayWishesProps) {
  const [visibleLines, setVisibleLines] = useState<number>(0);

  useEffect(() => {
    if (visibleLines < letterLines.length) {
      const timer = setTimeout(() => {
        setVisibleLines((prev) => prev + 1);
      }, 1400); // 1.4 seconds per line for comfortable reading transition
      return () => clearTimeout(timer);
    }
  }, [visibleLines]);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none py-12 overflow-hidden">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="max-w-xl w-full p-8 md:p-10 rounded-3xl bg-brand-cream/95 border-2 border-brand-grey/85 shadow-[0_22px_60px_rgba(92,75,64,0.12)] flex flex-col items-center gap-8 relative"
        id="wishes-letter-card"
      >
        <div className="absolute top-4 left-4 text-brand-brown/15"><Heart size={24} className="animate-pulse" /></div>
        <div className="absolute bottom-4 right-4 text-brand-brown/15"><Sparkles size={24} className="animate-spin" /></div>

        <h2 className="font-royal text-xl font-bold text-brand-brown tracking-widest uppercase">
          💌 Royal Surprise Wish 💌
        </h2>

        {/* Letter Lines container */}
        <div className="w-full text-center flex flex-col gap-4 font-content text-lg sm:text-xl text-brand-brown/85 font-medium leading-relaxed">
          {letterLines.map((line, idx) => {
            const isVisible = idx < visibleLines;
            const isSignature = idx === letterLines.length - 1;
            const isHeader = idx === 0;

            return (
              <div key={idx} className="min-h-[2rem] flex items-center justify-center">
                <AnimatePresence>
                  {isVisible && (
                    <motion.p
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.8, ease: 'easeOut' }}
                      className={`${
                        isHeader 
                          ? 'font-royal text-xl font-black text-brand-brown text-left w-full mb-2' 
                          : isSignature 
                          ? 'font-royal text-xl sm:text-2xl font-black text-[#6F4E37] mt-6 tracking-widest drop-shadow animate-pulse' 
                          : ''
                      }`}
                    >
                      {line}
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

        {/* Active show of Next page trigger */}
        <AnimatePresence>
          {visibleLines >= letterLines.length && (
            <motion.button
              id="wishes-next-btn"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05, backgroundColor: '#4A3D35' }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: 'spring', stiffness: 400, damping: 15 }}
              onClick={onNext}
              className="mt-4 px-6 py-3 rounded-xl bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest shadow-md flex items-center gap-2 border border-brand-brown cursor-pointer transition-colors"
            >
              ❤️ See Our Memory Wall ❤️
            </motion.button>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
