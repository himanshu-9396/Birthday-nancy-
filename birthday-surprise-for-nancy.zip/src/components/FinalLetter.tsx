import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Heart, RotateCcw } from 'lucide-react';

interface FinalLetterProps {
  onReplay: () => void;
}

const letterParagraphs = [
  'Thank You For Being You.',
  'Today is your day.',
  'Keep smiling.',
  'Keep shining.',
  'Keep chasing your dreams.',
  'Keep being the wonderful person you are.',
  'You deserve happiness, love, success, and everything beautiful in life.',
  '❤️ Happy Birthday Nancy ❤️',
];

interface FireworkParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  alpha: number;
  size: number;
}

export default function FinalLetter({ onReplay }: FinalLetterProps) {
  const [paraIndex, setParaIndex] = useState(0);
  const [showFinale, setShowFinale] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Auto staggered paragraph reveals on letter mode
  useEffect(() => {
    if (!showFinale && paraIndex < letterParagraphs.length) {
      const timer = setTimeout(() => {
        setParaIndex((prev) => prev + 1);
      }, 1500); // 1.5 seconds typing transition for emotional pacing
      return () => clearTimeout(timer);
    }
  }, [paraIndex, showFinale]);

  // Grand Finale Canvas Firework Simulation
  useEffect(() => {
    if (!showFinale) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const particles: FireworkParticle[] = [];
    const colors = ['#f43f5e', '#ec4899', '#d946ef', '#a855f7', '#60a5fa', '#34d399', '#fbbf24'];

    const spawnFirework = () => {
      const originX = Math.random() * width;
      const originY = height * 0.2 + Math.random() * (height * 0.4);
      const color = colors[Math.floor(Math.random() * colors.length)];
      const particleCount = 40 + Math.floor(Math.random() * 20);

      for (let i = 0; i < particleCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 2 + Math.random() * 6;
        particles.push({
          x: originX,
          y: originY,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color,
          alpha: 1.0,
          size: Math.random() * 3 + 2,
        });
      }
    };

    // Auto spawn fireworks periodically
    const spawnTimer = setInterval(spawnFirework, 900);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    let frameId: number;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Render & update firework fragments
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.08; // gravity drop
        p.alpha -= 0.012;

        if (p.alpha <= 0) {
          particles.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.shadowBlur = 10;
        ctx.shadowColor = p.color;
        ctx.fill();
        ctx.restore();
      }

      frameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      clearInterval(spawnTimer);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
    };
  }, [showFinale]);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none py-12 overflow-hidden">
      
      {/* Absolute Firework canvas overlay */}
      {showFinale && (
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full pointer-events-none z-10"
          id="fireworks-canvas"
        />
      )}

      {/* Decorative Hearts and Confetti layered overlay in React */}
      {showFinale && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
          {[...Array(25)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ y: -50, x: Math.random() * window.innerWidth, rotate: 0 }}
              animate={{ 
                y: window.innerHeight + 50, 
                rotate: 360,
                x: `calc(${Math.random() * 100}vw)`
              }}
              transition={{ 
                duration: 4 + Math.random() * 4, 
                repeat: Infinity,
                delay: i * 0.25 
              }}
              style={{ color: ['#f43f5e', '#ec4899', '#fbcfe8', '#fbbf24'][i % 4] }}
              className="absolute text-2xl"
            >
              {['❤️', '🎉', '💖', '✨', '🎈'][i % 5]}
            </motion.div>
          ))}
        </div>
      )}

      <div className="max-w-xl w-full flex flex-col items-center gap-10 relative z-30">
        <AnimatePresence mode="wait">
          {!showFinale ? (
            // Formatted Typewriter Letter Card (Page 10)
            <motion.div
              key="letter-card"
              initial={{ opacity: 0, scale: 0.9, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -20 }}
              className="w-full p-8 md:p-10 rounded-3xl bg-brand-cream border-2 border-brand-grey shadow-[0_20px_50px_rgba(92,75,64,0.12)] flex flex-col gap-6"
              id="final-letter-card"
            >
              <div className="flex justify-center text-4xl">💌👩‍🎨🎈</div>
              
              <div className="flex flex-col gap-5 text-center min-h-[30vh]">
                {letterParagraphs.map((line, idx) => {
                  const isVisible = idx < paraIndex;
                  const isLastLine = idx === letterParagraphs.length - 1;

                  return (
                    <div key={idx} className="min-h-[1.5rem] flex items-center justify-center">
                      <AnimatePresence>
                        {isVisible && (
                          <motion.p
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.7 }}
                            className={`font-content font-semibold tracking-wide text-base sm:text-lg text-brand-brown ${
                              isLastLine 
                                ? 'font-royal text-xl sm:text-2.5xl font-black text-brand-brown mt-4 py-2 animate-pulse uppercase tracking-widest' 
                                : ''
                            }`}
                          >
                            {line}
                          </motion.p>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>

              {paraIndex >= letterParagraphs.length && (
                <motion.button
                  id="final-letter-next-btn"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setShowFinale(true)}
                  className="mx-auto mt-4 px-8 py-3.5 rounded-xl bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest shadow-[0_6px_20px_rgba(92,75,64,0.25)] border border-brand-brown cursor-pointer transition-colors"
                >
                  🎇 Trigger Grand Finale 🎇
                </motion.button>
              )}
            </motion.div>
          ) : (
            // Grand Finale Celebration stage
            <motion.div
              key="finale-stage"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: 'spring', damping: 20 }}
              className="w-full text-center flex flex-col items-center gap-6"
              id="grand-finale-card"
            >
              <motion.div
                animate={{ scale: [1, 1.15, 1], rotate: [0, 1, -1, 0] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="w-24 h-24 rounded-full bg-brand-cream border-2 border-brand-grey flex items-center justify-center shadow-[0_10px_35px_rgba(92,75,64,0.06)] cursor-pointer"
              >
                <Heart size={48} fill="#f59e0b" className="text-amber-500 drop-shadow animate-pulse" />
              </motion.div>

              <div className="space-y-4">
                <h1 className="font-royal text-2xl sm:text-4.5xl font-black text-brand-brown leading-tight tracking-wider uppercase">
                  ✨ The End Of Your Birthday Surprise ✨
                </h1>
                
                <p className="font-royal text-xl sm:text-2.5xl font-extrabold text-brand-brown animate-pulse uppercase tracking-wider">
                  ❤️ Once Again, Happy Birthday Nancy ❤️
                </p>

                <p className="font-content text-base sm:text-lg text-[#6B5A50] max-w-md mx-auto leading-relaxed font-semibold">
                  Thank you for being such a bright stellar presence in the world. Enjoy every beautiful second of your special day!
                </p>
              </div>

              <motion.button
                id="btn-replay-surprise"
                whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
                whileTap={{ scale: 0.97 }}
                onClick={onReplay}
                className="mt-6 px-8 py-3.5 rounded-xl bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest shadow-[0_6px_20px_rgba(92,75,64,0.25)] border border-brand-brown flex items-center gap-2 cursor-pointer transition-colors"
              >
                <RotateCcw size={16} /> REPLAY SURPRISE
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
