import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Maximize2, X, ChevronRight } from 'lucide-react';

import nancyAvatar from '../assets/images/nancy_avatar_1780555399727.png';
import cuteTeddy from '../assets/images/cute_teddy_1780555413017.png';
import birthdayGirl from '../assets/images/birthday_girl_1780555428007.png';
import magicalGarden from '../assets/images/magical_garden_1780555441780.png';

interface MemoryWallProps {
  onNext: () => void;
}

interface Polaroid {
  id: number;
  url: string;
  caption: string;
  rotation: number; // in degrees
}

const POLAROIDS: Polaroid[] = [
  {
    id: 1,
    url: nancyAvatar,
    caption: 'Happy, smiles and radiant light ✨',
    rotation: -4,
  },
  {
    id: 2,
    url: cuteTeddy,
    caption: 'Warm wishes and cuddly heartbeams 💕',
    rotation: 5,
  },
  {
    id: 3,
    url: birthdayGirl,
    caption: 'Blowing wishful candle desires 🍓',
    rotation: -3,
  },
  {
    id: 4,
    url: magicalGarden,
    caption: 'Our magical dreaming wonderland 🌟',
    rotation: 4,
  },
];

export default function MemoryWall({ onNext }: MemoryWallProps) {
  const [activePhoto, setActivePhoto] = useState<Polaroid | null>(null);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none py-12 overflow-hidden">
      <div className="max-w-4xl w-full flex flex-col items-center gap-10">
        
        {/* Gallery Title Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-2"
        >
          <span className="text-3xl">🌸✨📸</span>
          <h2 className="font-royal text-2xl sm:text-3.5xl font-black text-brand-brown leading-tight tracking-wider uppercase">
            Every moment becomes special because of you
          </h2>
          <p className="font-content text-base sm:text-lg text-[#6B5A50] tracking-wide">
            Tap on any snapshot to amplify the sweet dream
          </p>
        </motion.div>

        {/* Polaroids Staggered Grid */}
        <div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 w-full max-w-4xl justify-center items-center px-4"
          id="memories-grid"
        >
          {POLAROIDS.map((p, index) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, scale: 0.8, y: 30, rotate: 0 }}
              animate={{ opacity: 1, scale: 1, y: 0, rotate: p.rotation }}
              whileHover={{ 
                scale: 1.05, 
                rotate: 0, 
                y: -10, 
                boxShadow: '0 22px 45px rgba(92,75,64,0.18)',
                zIndex: 10 
              }}
              transition={{ 
                duration: 0.8, 
                delay: index * 0.25, 
                type: 'spring', 
                stiffness: 150 
              }}
              onClick={() => setActivePhoto(p)}
              className="bg-brand-cream p-4 pb-6 rounded-md shadow-xl hover:shadow-[0_15px_30px_rgba(92,75,64,0.22)] origin-center group cursor-pointer transition-all border border-brand-grey flex flex-col items-center w-56 sm:w-full mx-auto"
              id={`polaroid-${p.id}`}
            >
              {/* Photo Frame Container */}
              <div className="relative w-full aspect-square overflow-hidden bg-brand-cream border border-brand-grey/50 rounded">
                <img
                  src={p.url}
                  alt={p.caption}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-md p-1.5 rounded-full text-[#F8F7F3] opacity-0 group-hover:opacity-100 transition-opacity">
                  <Maximize2 size={12} />
                </div>
              </div>

              {/* Polaroid Handwritten Caption */}
              <p className="font-hand text-xl md:text-2xl mt-4 text-[#503E35] font-bold text-center tracking-wide min-h-[2.5rem] flex items-center justify-center">
                {p.caption}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Transition Button */}
        <motion.button
          id="memory-next-btn"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
          whileTap={{ scale: 0.97 }}
          onClick={onNext}
          className="mt-6 px-8 py-3.5 rounded-xl bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest shadow-[0_6px_20px_rgba(92,75,64,0.25)] flex items-center gap-2 border border-brand-brown cursor-pointer transition-colors"
        >
          🎂 Let's Cut Your Cake! 🎂 <ChevronRight size={16} />
        </motion.button>
      </div>

      {/* Lightbox focus popup view */}
      <AnimatePresence>
        {activePhoto && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActivePhoto(null)}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 cursor-zoom-out"
          >
            <motion.div
              initial={{ scale: 0.85, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.85, y: 30 }}
              transition={{ type: 'spring', damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-brand-cream p-5 pb-8 rounded-2xl shadow-[0_24px_60px_rgba(92,75,64,0.3)] relative max-w-sm w-full border-2 border-brand-grey flex flex-col items-center"
            >
              {/* Close Button top-right */}
              <button 
                id="btn-close-lightbox"
                onClick={() => setActivePhoto(null)}
                className="absolute -top-3 -right-3 w-9 h-9 bg-brand-brown hover:bg-[#4A3D35] text-brand-cream rounded-xl flex items-center justify-center shadow-md border border-brand-brown cursor-pointer"
              >
                <X size={18} />
              </button>

              <div className="w-full aspect-square overflow-hidden bg-brand-cream rounded-xl border border-brand-grey">
                <img
                  src={activePhoto.url}
                  alt={activePhoto.caption}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              <p className="font-hand text-2.5xl mt-5 text-[#503E35] font-bold tracking-wide text-center leading-relaxed px-2">
                {activePhoto.caption}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
