import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  decay: number;
  color: string;
  type: 'star' | 'heart' | 'firefly' | 'trail-heart';
  angle?: number;
}

export default function BackgroundEffects() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const particles: Particle[] = [];

    // Initialize twinkling stars
    const starCount = 60;
    for (let i = 0; i < starCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: 0,
        vy: 0,
        size: Math.random() * 1.5 + 0.5,
        alpha: Math.random(),
        decay: 0.005 + Math.random() * 0.015,
        color: '#ffffff',
        type: 'star',
      });
    }

    // Initialize slow fireflies
    const fireflyCount = 20;
    for (let i = 0; i < fireflyCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: -0.2 - Math.random() * 0.3,
        size: Math.random() * 2 + 1.5,
        alpha: Math.random() * 0.6 + 0.4,
        decay: 0.002 + Math.random() * 0.005,
        color: 'rgba(253, 224, 71, 0.8)', // beautiful gold yellow glow
        type: 'firefly',
        angle: Math.random() * Math.PI * 2,
      });
    }

    // Slowly spawn ambient hearts
    let lastHeartSpawn = 0;

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Heart drawing helper
    const drawHeart = (c: CanvasRenderingContext2D, x: number, y: number, size: number, color: string, alpha: number) => {
      c.save();
      c.globalAlpha = alpha;
      c.beginPath();
      // Draw a perfect path for heart
      c.moveTo(x, y + size / 4);
      c.quadraticCurveTo(x, y, x - size / 2, y);
      c.quadraticCurveTo(x - size, y, x - size, y + size / 2);
      c.quadraticCurveTo(x - size, y + size, x, y + size * 1.4);
      c.quadraticCurveTo(x + size, y + size, x + size, y + size / 2);
      c.quadraticCurveTo(x + size, y, x + size / 2, y);
      c.quadraticCurveTo(x, y, x, y + size / 4);
      c.fillStyle = color;
      c.fill();
      c.restore();
    };

    // Track mouse to generate cursor trails
    const handleMouseMove = (e: MouseEvent) => {
      // Spawn standard trail heart
      if (Math.random() < 0.35) {
        particles.push({
          x: e.clientX,
          y: e.clientY,
          vx: (Math.random() - 0.5) * 1.5,
          vy: -1 - Math.random() * 1.5,
          size: Math.random() * 8 + 6,
          alpha: 1.0,
          decay: 0.015 + Math.random() * 0.015,
          color: `hsl(${340 + Math.random() * 30}, 100%, ${65 + Math.random() * 15}%)`, // Soft romantic pinks/reds
          type: 'trail-heart',
        });
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const touch = e.touches[0];
        if (Math.random() < 0.35) {
          particles.push({
            x: touch.clientX,
            y: touch.clientY,
            vx: (Math.random() - 0.5) * 1.5,
            vy: -1 - Math.random() * 1.5,
            size: Math.random() * 8 + 6,
            alpha: 1.0,
            decay: 0.015 + Math.random() * 0.015,
            color: `hsl(${340 + Math.random() * 30}, 100%, ${65 + Math.random() * 15}%)`,
            type: 'trail-heart',
          });
        }
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('touchmove', handleTouchMove, { passive: true });

    // Main animation loop
    const render = (timestamp: number) => {
      ctx.fillStyle = '#f5f2eb'; // Warm elegant ivory/linen
      ctx.fillRect(0, 0, width, height);

      // Create a gorgeous ambient vignette gradient with muted cream/warm grey tones
      const grad = ctx.createRadialGradient(width / 2, height / 2, 20, width / 2, height / 2, Math.max(width, height) * 0.85);
      grad.addColorStop(0, '#fbfaf8'); // Soft warm milk-white
      grad.addColorStop(0.5, '#f3efe6'); // Elegant ivory
      grad.addColorStop(1, '#e3ded3'); // Beautiful muted bone grey
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Ambient heart spawner - soft dusty rose / clay latte tone
      if (timestamp - lastHeartSpawn > 1400) {
        particles.push({
          x: Math.random() * width,
          y: height + 20,
          vx: (Math.random() - 0.5) * 0.35,
          vy: -0.4 - Math.random() * 0.6,
          size: Math.random() * 8 + 6,
          alpha: 0.05,
          decay: -0.003, // will grow alpha first, then shrink
          color: `rgba(${163 + Math.floor(Math.random() * 30)}, ${142 + Math.floor(Math.random() * 20)}, ${129}, 0.25)`, // soft warm taupe
          type: 'heart',
          angle: 0.1,
        });
        lastHeartSpawn = timestamp;
      }

      // Render/Update all particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];

        if (p.type === 'star') {
          // Twinkle - soft warm cream stars
          p.alpha += p.decay;
          if (p.alpha > 0.8 || p.alpha < 0.15) {
            p.decay = -p.decay;
          }
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(180, 160, 140, ${Math.max(0.15, Math.min(0.8, p.alpha))})`;
          ctx.fill();
        } 
        else if (p.type === 'firefly') {
          // Oscillating flight path like a firefly - amber warmth
          if (p.angle !== undefined) {
            p.angle += 0.015;
            p.x += Math.sin(p.angle) * 0.25;
          }
          p.y += p.vy;

          if (p.y < -10) {
            p.y = height + 10;
            p.x = Math.random() * width;
          }

          // Gentle alpha pulsing
          p.alpha += p.decay;
          if (p.alpha > 0.8 || p.alpha < 0.2) {
            p.decay = -p.decay;
          }

          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.shadowBlur = 8;
          ctx.shadowColor = 'rgba(212, 163, 115, 0.4)';
          ctx.fillStyle = `rgba(212, 163, 115, ${Math.max(0.2, Math.min(0.8, p.alpha))})`; // soft ochre
          ctx.fill();
          ctx.shadowBlur = 0; // reset
        } 
        else if (p.type === 'trail-heart') {
          p.x += p.vx;
          p.y += p.vy;
          p.alpha -= p.decay;

          if (p.alpha <= 0) {
            particles.splice(i, 1);
            continue;
          }

          // soft earthy clay/camel color for trail
          const hue = 25 + Math.random() * 15; // camel/latte warm tone
          drawHeart(ctx, p.x, p.y, p.size, `hsla(${hue}, 20%, 60%, ${p.alpha})`, p.alpha);
        }
        else if (p.type === 'heart') {
          // Ambient rising heart
          p.x += p.vx;
          p.y += p.vy;

          // Grow in visibility, then fade
          if (p.angle === 0.1) {
            p.alpha += 0.008;
            if (p.alpha >= 0.4) p.angle = 0.2;
          } else {
            p.alpha -= 0.003;
          }

          if (p.y < -30 || p.alpha <= 0) {
            particles.splice(i, 1);
            continue;
          }

          drawHeart(ctx, p.x, p.y, p.size, p.color, p.alpha);
        }
      }

      animationId = requestAnimationFrame(render);
    };

    animationId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('touchmove', handleTouchMove);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none -z-10 bg-[#f5f2eb]"
      id="bg-effects-canvas"
    />
  );
}
