import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Heart } from 'lucide-react';

interface StarryWishSkyProps {
  onNext: () => void;
}

interface StarNode {
  id: number;
  cx: number; // percentage width
  cy: number; // percentage height
  size: number;
  glow: boolean;
  clicked: boolean;
}

interface WishExplosion {
  id: number;
  x: number;
  y: number;
}

export default function StarryWishSky({ onNext }: StarryWishSkyProps) {
  const [stars, setStars] = useState<StarNode[]>([]);
  const [explosions, setExplosions] = useState<WishExplosion[]>([]);
  const [wishesCount, setWishesCount] = useState(0);

  // Initialize random constellation positions
  useEffect(() => {
    const list: StarNode[] = [];
    for (let i = 0; i < 7; i++) {
      list.push({
        id: i,
        cx: 12 + Math.random() * 76,
        cy: 18 + Math.random() * 40,
        size: Math.random() * 1.5 + 1.2,
        glow: Math.random() > 0.45,
        clicked: false,
      });
    }
    setStars(list);
  }, []);

  // Periodic star glowing toggle
  useEffect(() => {
    const interval = setInterval(() => {
      setStars((prev) =>
        prev.map((star) =>
          Math.random() < 0.35 ? { ...star, glow: !star.glow } : star
        )
      );
    }, 1200);
    return () => clearInterval(interval);
  }, []);

  const handleStarClick = (e: React.MouseEvent<SVGSVGElement>, id: number) => {
    const star = stars.find((s) => s.id === id);
    if (!star || star.clicked) return;

    // Set star clicked state
    setStars((prev) =>
      prev.map((s) => (s.id === id ? { ...s, clicked: true } : s))
    );

    setWishesCount((prev) => prev + 1);

    // Get click positions for explosion origin
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Add heart spark explosion
    const explosionId = Date.now();
    setExplosions((prev) => [...prev, { id: explosionId, x: clickX, y: clickY }]);

    // Play a delightful tiny bell chime!
    playStarAudioChime();
  };

  const playStarAudioChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      // Clear high bell frequency
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880 + Math.random() * 440, audioCtx.currentTime); // High sweet chimes

      gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.18, audioCtx.currentTime + 0.05);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.6);

      osc.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + 0.65);
    } catch (e) {}
  };

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none py-10 overflow-hidden">
      
      {/* Decorative Constellations SVG Layer */}
      <div className="absolute inset-0 bg-[#0c031a]/15 z-0 pointer-events-none" />

      <div className="max-w-xl w-full flex flex-col items-center gap-6 relative z-10">
        
        {/* Sky Wishes Title instructions */}
        <div className="space-y-2">
          <motion.h2
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-royal text-2xl sm:text-3xl font-black text-brand-brown tracking-widest uppercase"
          >
            Make a wish... 🌟
          </motion.h2>
          <p className="font-content text-base sm:text-lg text-brand-brown/80 leading-relaxed max-w-sm mx-auto font-semibold">
            Tonight every single star is celebrating you. Tap a wishing star to watch it rise!
          </p>
        </div>

        {/* Constance interactive viewport */}
        <div className="relative w-full aspect-video sm:aspect-square md:aspect-video max-w-lg min-h-[16rem] bg-brand-cream/90 rounded-3xl border-2 border-brand-grey p-4 overflow-hidden shadow-[inset_0_2px_8px_rgba(92,75,64,0.05),0_10px_30px_rgba(92,75,64,0.06)] backdrop-blur-sm">
          
          {/* Shooting stars elements */}
          <div className="absolute top-10 -left-20 w-32 h-0.5 bg-gradient-to-r from-stone-400 to-transparent rotate-25 opacity-30 animate-[shooting_5s_infinite_linear]" />
          <div className="absolute top-32 -left-20 w-24 h-0.5 bg-gradient-to-r from-stone-400 to-transparent rotate-25 opacity-20 animate-[shooting_7s_infinite_linear_1.5s]" />

          <svg 
            className="w-full h-full relative cursor-crosshair z-10"
            style={{ touchAction: 'none' }}
          >
            {/* Draw Constellation lines between stars (dreamy linkage) */}
            <path
              d={stars
                .filter((s, i) => i % 2 === 0)
                .map((s, idx) => `${idx === 0 ? 'M' : 'L'} ${s.cx}% ${s.cy}%`)
                .join(' ')}
              stroke="rgba(92,75,64,0.18)"
              strokeWidth="1.2"
              fill="none"
              strokeDasharray="3 4"
            />

            {/* Stars Nodes */}
            {stars.map((star) => {
              const isGlowing = star.glow || star.clicked;
              return (
                <motion.g 
                  key={star.id} 
                  id={`wishing-star-${star.id}`}
                  className="cursor-pointer group select-none"
                  onClick={(e) => handleStarClick(e, star.id)}
                  animate={star.clicked ? {
                    y: -100,
                    opacity: [1, 1, 0],
                    scale: [1, 1.4, 0.6],
                  } : {
                    y: 0,
                    opacity: 1,
                    scale: 1,
                  }}
                  transition={star.clicked ? {
                    duration: 2.8,
                    times: [0, 0.6, 1],
                    ease: "easeOut"
                  } : {
                    duration: 0.3
                  }}
                >
                  {/* Outer lighting flare glow aura */}
                  <circle
                    cx={`${star.cx}%`}
                    cy={`${star.cy}%`}
                    r={star.clicked ? 28 : isGlowing ? 20 : 12}
                    fill="#fbbf24"
                    fillOpacity={star.clicked ? 0.5 : isGlowing ? 0.35 : 0.12}
                    className="transition-all duration-700 animate-pulse"
                    style={{
                      filter: 'blur(5px)',
                    }}
                  />
                  
                  {/* Additional intense core warm pink aura */}
                  <circle
                    cx={`${star.cx}%`}
                    cy={`${star.cy}%`}
                    r={star.clicked ? 18 : isGlowing ? 12 : 6}
                    fill="#ec4899"
                    fillOpacity={star.clicked ? 0.45 : isGlowing ? 0.25 : 0.08}
                    className="transition-all duration-500 animate-pulse"
                    style={{
                      filter: 'blur(2px)',
                    }}
                  />

                  {/* High fidelity glowing star emoji (⭐) text node with intense drop shadows */}
                  <text
                    x={`${star.cx}%`}
                    y={`${star.cy}%`}
                    textAnchor="middle"
                    dominantBaseline="central"
                    className="select-none pointer-events-none transition-all duration-500"
                    style={{
                      fontSize: star.clicked ? '30px' : isGlowing ? '24px' : '16px',
                      filter: isGlowing 
                        ? 'drop-shadow(0 0 10px #fbbf24) drop-shadow(0 0 18px #f59e0b) drop-shadow(0 0 25px #ec4899)' 
                        : 'drop-shadow(0 0 3px rgba(245, 158, 11, 0.3))',
                      cursor: 'pointer',
                    }}
                  >
                    ⭐
                  </text>
                </motion.g>
              );
            })}
          </svg>

          {/* Render explosions on click */}
          {explosions.map((exp) => (
            <div 
              key={exp.id} 
              className="absolute pointer-events-none" 
              style={{ left: exp.x, top: exp.y }}
            >
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ scale: 0.6, opacity: 1, x: 0, y: 0 }}
                  animate={{
                    scale: 0.2,
                    opacity: 0,
                    x: Math.sin(i * Math.PI * 0.25) * 45,
                    y: -15 + Math.cos(i * Math.PI * 0.25) * 45,
                  }}
                  transition={{ duration: 1.0, ease: 'easeOut' }}
                  className="absolute -ml-2 -mt-2 text-amber-500"
                >
                  <Heart size={14} fill="#fbbf24" />
                </motion.div>
              ))}
            </div>
          ))}

        </div>

        {/* Dynamic score keeper wishes count */}
        <div className="h-14 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {wishesCount < 3 ? (
              <motion.p
                key="count"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="font-content text-base text-brand-brown/70 font-semibold"
              >
                🔮 Tap at least <span className="font-extrabold text-[#5C4B40] bg-white border border-[#D1CFCB]/80 px-1.5 py-0.5 rounded">{3 - wishesCount}</span> stars to send wishes up!
              </motion.p>
            ) : (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex flex-col items-center gap-1.5"
              >
                <p className="font-royal text-xs sm:text-sm text-[#7F5B44] font-extrabold flex items-center gap-1 uppercase tracking-widest bg-brand-cream px-3 py-1.5 rounded-full border border-brand-grey/85">
                  🕊️ Your wishes are flying high!
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Continue Button */}
        <AnimatePresence>
          {wishesCount >= 3 && (
            <motion.button
              id="wishes-complete-btn"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
              whileTap={{ scale: 0.97 }}
              onClick={onNext}
              className="px-8 py-3.5 rounded-xl bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest shadow-[0_6px_20px_rgba(92,75,64,0.25)] border border-brand-brown cursor-pointer transition-colors"
            >
              💌 Read Final Letter 💌
            </motion.button>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
