import React, { useState } from 'react';
import { PageId } from './types';
import BackgroundEffects from './components/BackgroundEffects';
import WelcomeScreen from './components/WelcomeScreen';
import PasswordGate from './components/PasswordGate';
import CardMatchingGame from './components/CardMatchingGame';
import MagicalTree from './components/MagicalTree';
import BirthdayWishes from './components/BirthdayWishes';
import MemoryWall from './components/MemoryWall';
import CakeCutting from './components/CakeCutting';
import GiftBoxSurprise from './components/GiftBoxSurprise';
import StarryWishSky from './components/StarryWishSky';
import FinalLetter from './components/FinalLetter';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('welcome');
  const [pastedPassword, setPastedPassword] = useState('');

  const handleNextPage = (next: PageId) => {
    setCurrentPage(next);
  };

  const handleRestart = () => {
    setPastedPassword('');
    setCurrentPage('welcome');
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'welcome':
        return (
          <motion.div
            key="welcome-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <WelcomeScreen onNext={() => handleNextPage('password')} />
          </motion.div>
        );
      case 'password':
        return (
          <motion.div
            key="password-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <PasswordGate
              onUnlock={() => handleNextPage('magical-tree')}
              onGoToGame={() => handleNextPage('matching-game')}
              initialPassword={pastedPassword}
            />
          </motion.div>
        );
      case 'matching-game':
        return (
          <motion.div
            key="matching-game-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <CardMatchingGame
              onBack={() => handleNextPage('password')}
              onPastePassword={(password) => {
                setPastedPassword(password);
                handleNextPage('password');
              }}
            />
          </motion.div>
        );
      case 'magical-tree':
        return (
          <motion.div
            key="magical-tree-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <MagicalTree onComplete={() => handleNextPage('birthday-wishes')} />
          </motion.div>
        );
      case 'birthday-wishes':
        return (
          <motion.div
            key="wishes-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <BirthdayWishes onNext={() => handleNextPage('memory-wall')} />
          </motion.div>
        );
      case 'memory-wall':
        return (
          <motion.div
            key="memory-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <MemoryWall onNext={() => handleNextPage('cake-cutting')} />
          </motion.div>
        );
      case 'cake-cutting':
        return (
          <motion.div
            key="cake-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <CakeCutting onNext={() => handleNextPage('gift-box')} />
          </motion.div>
        );
      case 'gift-box':
        return (
          <motion.div
            key="gift-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <GiftBoxSurprise onNext={() => handleNextPage('starry-sky')} />
          </motion.div>
        );
      case 'starry-sky':
        return (
          <motion.div
            key="starry-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <StarryWishSky onNext={() => handleNextPage('final-letter')} />
          </motion.div>
        );
      case 'final-letter':
        return (
          <motion.div
            key="letter-pg"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="w-full flex justify-center"
          >
            <FinalLetter onReplay={handleRestart} />
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col justify-between overflow-x-hidden text-stone-800" id="root-layout-wrapper">
      {/* Background Interactive canvas trails & fireflies */}
      <BackgroundEffects />

      {/* Main Container Stage */}
      <main className="flex-grow w-full flex items-center justify-center relative z-10 py-6">
        <AnimatePresence mode="wait">
          {renderCurrentPage()}
        </AnimatePresence>
      </main>
    </div>
  );
}
