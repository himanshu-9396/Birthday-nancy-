export interface PolaroidPhoto {
  id: number;
  url: string;
  caption: string;
}

export type PageId =
  | 'welcome'
  | 'password'
  | 'matching-game'
  | 'magical-tree'
  | 'birthday-wishes'
  | 'memory-wall'
  | 'cake-cutting'
  | 'gift-box'
  | 'starry-sky'
  | 'final-letter'
  | 'finale';
