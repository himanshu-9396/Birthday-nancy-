import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface MagicalTreeProps {
  onComplete: () => void;
}

interface HeartLeaf {
  x: number;
  y: number;
  size: number;
  color: string;
  greenColor: string;
  rot: number;
  delay: number;
}

// 73 dense leaves forming a beautiful heart-shaped canopy overall
const HEART_LEAVES: HeartLeaf[] = [
  // Outer silhouette of the grand heart
  { x: 100, y: 44, size: 0.7, color: '#dc2626', greenColor: '#16a34a', rot: 0, delay: 0.1 },  // Top center indent
  { x: 94, y: 40, size: 0.6, color: '#ef4444', greenColor: '#22c55e', rot: -10, delay: 0.15 },
  { x: 86, y: 36, size: 0.8, color: '#b91c1c', greenColor: '#15803d', rot: -20, delay: 0.2 },
  { x: 74, y: 34, size: 0.85, color: '#dc2626', greenColor: '#16a34a', rot: -25, delay: 0.25 },
  { x: 64, y: 38, size: 0.9, color: '#ef4444', greenColor: '#22c55e', rot: -30, delay: 0.3 },
  { x: 54, y: 46, size: 0.8, color: '#f87171', greenColor: '#86efac', rot: -35, delay: 0.35 },
  { x: 46, y: 56, size: 0.85, color: '#dc2626', greenColor: '#16a34a', rot: -45, delay: 0.4 },
  { x: 42, y: 68, size: 0.9, color: '#ef4444', greenColor: '#22c55e', rot: -50, delay: 0.45 },
  { x: 40, y: 80, size: 0.8, color: '#b91c1c', greenColor: '#15803d', rot: -40, delay: 0.5 },
  { x: 44, y: 94, size: 0.85, color: '#dc2626', greenColor: '#16a34a', rot: -30, delay: 0.55 },
  { x: 52, y: 106, size: 0.9, color: '#ef4444', greenColor: '#22c55e', rot: -20, delay: 0.6 },
  { x: 62, y: 118, size: 0.8, color: '#f87171', greenColor: '#86efac', rot: -15, delay: 0.65 },
  { x: 74, y: 130, size: 0.85, color: '#dc2626', greenColor: '#16a34a', rot: -10, delay: 0.7 },
  { x: 86, y: 142, size: 0.9, color: '#ef4444', greenColor: '#22c55e', rot: -5, delay: 0.75 },
  { x: 100, y: 154, size: 0.95, color: '#b91c1c', greenColor: '#15803d', rot: 0, delay: 0.8 },  // Bottom tip

  // Right-side outer silhouette
  { x: 106, y: 40, size: 0.6, color: '#ef4444', greenColor: '#22c55e', rot: 10, delay: 0.15 },
  { x: 114, y: 36, size: 0.8, color: '#b91c1c', greenColor: '#15803d', rot: 20, delay: 0.2 },
  { x: 126, y: 34, size: 0.85, color: '#dc2626', greenColor: '#16a34a', rot: 25, delay: 0.25 },
  { x: 136, y: 38, size: 0.9, color: '#ef4444', greenColor: '#22c55e', rot: 30, delay: 0.3 },
  { x: 146, y: 46, size: 0.8, color: '#f87171', greenColor: '#86efac', rot: 35, delay: 0.35 },
  { x: 154, y: 56, size: 0.85, color: '#dc2626', greenColor: '#16a34a', rot: 45, delay: 0.4 },
  { x: 158, y: 68, size: 0.9, color: '#ef4444', greenColor: '#22c55e', rot: 50, delay: 0.45 },
  { x: 160, y: 80, size: 0.8, color: '#b91c1c', greenColor: '#15803d', rot: 40, delay: 0.5 },
  { x: 156, y: 94, size: 0.85, color: '#dc2626', greenColor: '#16a34a', rot: 30, delay: 0.55 },
  { x: 148, y: 106, size: 0.9, color: '#ef4444', greenColor: '#22c55e', rot: 20, delay: 0.6 },
  { x: 138, y: 118, size: 0.8, color: '#f87171', greenColor: '#86efac', rot: 15, delay: 0.65 },
  { x: 126, y: 130, size: 0.85, color: '#dc2626', greenColor: '#16a34a', rot: 10, delay: 0.7 },
  { x: 114, y: 142, size: 0.9, color: '#ef4444', greenColor: '#22c55e', rot: 5, delay: 0.75 },

  // Inner Layer silhouette (nesting inside to build density - medium/small elements)
  { x: 100, y: 56, size: 0.75, color: '#dc2626', greenColor: '#16a34a', rot: 0, delay: 0.2 },
  { x: 90, y: 52, size: 0.65, color: '#ef4444', greenColor: '#22c55e', rot: -12, delay: 0.25 },
  { x: 80, y: 50, size: 0.7, color: '#b91c1c', greenColor: '#15803d', rot: -18, delay: 0.3 },
  { x: 70, y: 52, size: 0.6, color: '#dc2626', greenColor: '#16a34a', rot: -22, delay: 0.35 },
  { x: 60, y: 60, size: 0.65, color: '#ef4444', greenColor: '#22c55e', rot: -30, delay: 0.4 },
  { x: 54, y: 72, size: 0.7, color: '#f87171', greenColor: '#86efac', rot: -35, delay: 0.45 },
  { x: 52, y: 84, size: 0.65, color: '#dc2626', greenColor: '#16a34a', rot: -25, delay: 0.5 },
  { x: 58, y: 98, size: 0.75, color: '#ef4444', greenColor: '#22c55e', rot: -18, delay: 0.55 },
  { x: 68, y: 110, size: 0.7, color: '#b91c1c', greenColor: '#15803d', rot: -12, delay: 0.6 },
  { x: 80, y: 122, size: 0.65, color: '#dc2626', greenColor: '#16a34a', rot: -8, delay: 0.65 },
  { x: 92, y: 134, size: 0.7, color: '#ef4444', greenColor: '#22c55e', rot: -4, delay: 0.7 },

  // Right-side inner layer
  { x: 110, y: 52, size: 0.65, color: '#ef4444', greenColor: '#22c55e', rot: 12, delay: 0.25 },
  { x: 120, y: 50, size: 0.7, color: '#b91c1c', greenColor: '#15803d', rot: 18, delay: 0.3 },
  { x: 130, y: 52, size: 0.6, color: '#dc2626', greenColor: '#16a34a', rot: 22, delay: 0.35 },
  { x: 140, y: 60, size: 0.65, color: '#ef4444', greenColor: '#22c55e', rot: 30, delay: 0.4 },
  { x: 146, y: 72, size: 0.7, color: '#f87171', greenColor: '#86efac', rot: 35, delay: 0.45 },
  { x: 148, y: 84, size: 0.65, color: '#dc2626', greenColor: '#16a34a', rot: 25, delay: 0.5 },
  { x: 142, y: 98, size: 0.75, color: '#ef4444', greenColor: '#22c55e', rot: 18, delay: 0.55 },
  { x: 132, y: 110, size: 0.7, color: '#b91c1c', greenColor: '#15803d', rot: 12, delay: 0.6 },
  { x: 120, y: 122, size: 0.65, color: '#dc2626', greenColor: '#16a34a', rot: 8, delay: 0.65 },
  { x: 108, y: 134, size: 0.7, color: '#ef4444', greenColor: '#22c55e', rot: 4, delay: 0.7 },

  // Inner Core fillers (providing deep volume/ghane leaves)
  { x: 100, y: 72, size: 0.55, color: '#b91c1c', greenColor: '#15803d', rot: -5, delay: 0.3 },
  { x: 90, y: 66, size: 0.5, color: '#dc2626', greenColor: '#16a34a', rot: 15, delay: 0.34 },
  { x: 80, y: 64, size: 0.6, color: '#ef4444', greenColor: '#22c55e', rot: -10, delay: 0.38 },
  { x: 70, y: 68, size: 0.45, color: '#f87171', greenColor: '#86efac', rot: 12, delay: 0.42 },
  { x: 66, y: 80, size: 0.55, color: '#dc2626', greenColor: '#16a34a', rot: -18, delay: 0.46 },
  { x: 70, y: 92, size: 0.5, color: '#ef4444', greenColor: '#22c55e', rot: 8, delay: 0.5 },
  { x: 80, y: 104, size: 0.6, color: '#b91c1c', greenColor: '#15803d', rot: -15, delay: 0.54 },
  { x: 90, y: 114, size: 0.5, color: '#dc2626', greenColor: '#16a34a', rot: 5, delay: 0.58 },

  { x: 110, y: 66, size: 0.5, color: '#dc2626', greenColor: '#16a34a', rot: -15, delay: 0.34 },
  { x: 120, y: 64, size: 0.6, color: '#ef4444', greenColor: '#22c55e', rot: 10, delay: 0.38 },
  { x: 130, y: 68, size: 0.45, color: '#f87171', greenColor: '#86efac', rot: -12, delay: 0.42 },
  { x: 134, y: 80, size: 0.55, color: '#dc2626', greenColor: '#16a34a', rot: 18, delay: 0.46 },
  { x: 130, y: 92, size: 0.5, color: '#ef4444', greenColor: '#22c55e', rot: -8, delay: 0.5 },
  { x: 120, y: 104, size: 0.6, color: '#b91c1c', greenColor: '#15803d', rot: 15, delay: 0.54 },
  { x: 110, y: 114, size: 0.5, color: '#dc2626', greenColor: '#16a34a', rot: -5, delay: 0.58 },

  // Center-most high density canopy fillers
  { x: 100, y: 86, size: 0.5, color: '#dc2626', greenColor: '#16a34a', rot: 0, delay: 0.4 },
  { x: 90, y: 82, size: 0.45, color: '#ef4444', greenColor: '#22c55e', rot: -15, delay: 0.44 },
  { x: 110, y: 82, size: 0.45, color: '#ef4444', greenColor: '#22c55e', rot: 15, delay: 0.44 },
  { x: 100, y: 98, size: 0.55, color: '#b91c1c', greenColor: '#15803d', rot: 8, delay: 0.48 },
  { x: 90, y: 94, size: 0.4, color: '#dc2626', greenColor: '#16a34a', rot: -12, delay: 0.52 },
  { x: 110, y: 94, size: 0.4, color: '#dc2626', greenColor: '#16a34a', rot: 12, delay: 0.52 },
  { x: 100, y: 110, size: 0.5, color: '#ef4444', greenColor: '#22c55e', rot: -5, delay: 0.56 },
  { x: 92, y: 104, size: 0.4, color: '#f87171', greenColor: '#86efac', rot: 10, delay: 0.6 },
  { x: 108, y: 104, size: 0.4, color: '#f87171', greenColor: '#86efac', rot: -10, delay: 0.6 }
];

export default function MagicalTree({ onComplete }: MagicalTreeProps) {
  const [phase, setPhase] = useState(0);
  const [heartProgress, setHeartProgress] = useState(0);

  // Sort leaves from bottom-to-top (descending by y-coordinate) so they sprout from branches upwards
  const sortedLeaves = React.useMemo(() => {
    return [...HEART_LEAVES].sort((a, b) => b.y - a.y);
  }, []);

  // Growth sequence phases triggered step-by-step
  useEffect(() => {
    const playSequences = async () => {
      // 0: Trunk grows (wood)
      // 1: Branches grow (wood)
      // 2: Wood grown complete
      // 3: Green dense leaves sprout staggered (needs ~4.5s)
      // 4: Green leaves transform beautifully into glowing Red Hearts one by one!
      // 5: Quote and Proceed button appear
      const delays = [1400, 1400, 1000, 4500, 5000, 1000];
      for (let i = 0; i < delays.length; i++) {
        await new Promise((res) => setTimeout(res, delays[i]));
        setPhase((prev) => prev + 1);
      }
    };
    playSequences();
  }, []);

  // Animate the hearts transforming/popping up one-by-one once Phase 4 begins
  useEffect(() => {
    if (phase === 4) {
      let current = 0;
      const interval = setInterval(() => {
        current += 1;
        setHeartProgress(current);
        if (current >= sortedLeaves.length) {
          clearInterval(interval);
        }
      }, 42); // Spaced out pops for extremely clean one-by-one sequence
      return () => clearInterval(interval);
    }
  }, [phase, sortedLeaves]);

  // Growth narration text
  const phaseText = () => {
    switch (phase) {
      case 0: return '🪵 Tree trunk starts raising...';
      case 1: return '🌿 Wooden branches expand beautifully...';
      case 2: return '🌳 Strong wooden tree is fully grown!';
      case 3: return '🍃 Dense green leaves blossom...';
      case 4: return '♥️ Leaves transform into majestic red hearts!';
      default: return 'The beautiful wish tree is fully bloomed';
    }
  };

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none overflow-hidden py-10">
      <div className="max-w-xl w-full flex flex-col items-center justify-between min-h-[80vh] gap-6">
        
        {/* Phase Header */}
        <div className="h-16 flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.h2
              key={phase}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.5 }}
              className="font-sans text-lg sm:text-xl font-bold text-brand-brown tracking-widest uppercase"
            >
              {phaseText()}
            </motion.h2>
          </AnimatePresence>
        </div>

        {/* Scaled/Enlarged SVG Tree Stage based on prompt ("Or tress ko bada karo") */}
        <div 
          className="relative flex items-center justify-center w-80 h-80 sm:w-[460px] sm:h-[460px] md:w-[540px] md:h-[540px] lg:w-[600px] lg:h-[600px] my-6 transition-all duration-700" 
          id="magical-tree-stage"
        >
          <svg 
            viewBox="0 0 200 200" 
            className="w-full h-full drop-shadow-[0_8px_32px_rgba(120,61,25,0.12)]"
          >
            
            {/* Elegant horizontal ground reference to stabilize layout */}
            <line x1="40" y1="175" x2="160" y2="175" stroke="rgba(120, 61, 25, 0.12)" strokeWidth="2.5" strokeLinecap="round" />

            {/* Tree Limbs drawn with natural wood brown colors (no blue!) */}
            <g>
              {/* Left Trunk Line */}
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: phase >= 0 ? 1 : 0 }}
                transition={{ duration: 1.3, ease: "easeOut" }}
                d="M 86 175 C 93 140, 95 110, 88 95"
                stroke="#5c4033"
                strokeWidth="5.5"
                strokeLinecap="round"
                fill="none"
              />

              {/* Right Trunk Line */}
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: phase >= 0 ? 1 : 0 }}
                transition={{ duration: 1.3, ease: "easeOut" }}
                d="M 119 175 C 111 140, 107 110, 113 85"
                stroke="#5c4033"
                strokeWidth="5.5"
                strokeLinecap="round"
                fill="none"
              />

              {/* Left Upper Branch */}
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: phase >= 1 ? 1 : 0 }}
                transition={{ duration: 1.1, ease: "easeOut" }}
                d="M 88 95 Q 78 94, 65 96"
                stroke="#783d19"
                strokeWidth="3.5"
                strokeLinecap="round"
                fill="none"
              />

              {/* Left Lower Branch */}
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: phase >= 1 ? 1 : 0 }}
                transition={{ duration: 1.1, ease: "easeOut" }}
                d="M 85 125 C 78 126, 70 124, 62 127"
                stroke="#854d0e"
                strokeWidth="3"
                strokeLinecap="round"
                fill="none"
              />

              {/* Right Upper Branch */}
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: phase >= 1 ? 1 : 0 }}
                transition={{ duration: 1.1, ease: "easeOut" }}
                d="M 113 85 Q 124 76, 135 71"
                stroke="#783d19"
                strokeWidth="3.5"
                strokeLinecap="round"
                fill="none"
              />

              {/* Right Lower Branch */}
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: phase >= 1 ? 1 : 0 }}
                transition={{ duration: 1.1, ease: "easeOut" }}
                d="M 118 110 Q 128 106, 136 105"
                stroke="#854d0e"
                strokeWidth="3"
                strokeLinecap="round"
                fill="none"
              />
            </g>

            {/* Dense Organic Leaves making a heart-shaped silhouette (Phase 3+) */}
            {phase >= 3 && (
              <g>
                {sortedLeaves.map((item, idx) => {
                  const LEAF_PATH = "M12,3 Q18,9 12,21 Q6,9 12,3 Z";
                  const HEART_PATH = "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z";

                  // At phase 3, they render as gorgeous green leaves. At level 4+, they turn into red heart shapes!
                  const isHeart = phase > 4 || (phase === 4 && idx < heartProgress);

                  return (
                    <g 
                      key={idx}
                      transform={`translate(${item.x}, ${item.y - 22}) scale(${item.size * 0.85}) rotate(${item.rot}) translate(-12, -12)`}
                    >
                      <motion.path
                        key={isHeart ? `heart-item-${idx}` : `leaf-item-${idx}`}
                        d={isHeart ? HEART_PATH : LEAF_PATH}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ 
                          scale: 1,
                          opacity: 1,
                          y: isHeart ? [0, -4, 0] : 0
                        }}
                        transition={{
                          scale: isHeart 
                            ? {
                                type: 'spring',
                                stiffness: 220,
                                damping: 11,
                              }
                            : {
                                type: 'spring', 
                                stiffness: 95, 
                                damping: 13, 
                                delay: idx * 0.04, // Beautiful staggered one-by-one entry for green leaves!
                              },
                          opacity: { 
                            duration: 0.3,
                            delay: isHeart ? 0 : idx * 0.04
                          },
                          y: {
                            repeat: Infinity,
                            duration: 2.2 + (idx % 10) * 0.15,
                            ease: "easeInOut",
                          }
                        }}
                        fill={isHeart ? item.color : item.greenColor}
                        className="transition-colors duration-500"
                        style={{
                          filter: isHeart ? 'drop-shadow(0 0 6px rgba(220, 38, 38, 0.6))' : 'none'
                        }}
                      />
                    </g>
                  );
                })}
              </g>
            )}
          </svg>
        </div>

        {/* Wish Quote block and Explicit Action Continue button */}
        <div className="min-h-36 px-4 flex flex-col items-center justify-center gap-6 w-full">
          <AnimatePresence mode="wait">
            {phase >= 5 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="flex flex-col items-center gap-5 w-full max-w-sm"
              >
                <div className="p-5 rounded-2xl bg-brand-cream/95 border-2 border-brand-grey/85 backdrop-blur-sm shadow-[0_12px_36px_rgba(92,75,64,0.06)] text-center animate-fade-in">
                  <p className="font-content italic text-lg sm:text-xl text-brand-brown font-bold leading-relaxed">
                    "Just like this tree, my wishes for you grow bigger every day"
                  </p>
                </div>

                <motion.button
                  id="btn-tree-next"
                  whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
                  whileTap={{ scale: 0.97 }}
                  onClick={onComplete}
                  className="px-8 py-3.5 rounded-xl bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest shadow-[0_6px_20px_rgba(92,75,64,0.25)] flex items-center gap-2 border border-brand-brown cursor-pointer transition-colors"
                >
                  Proceed
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </div>
  );
}
