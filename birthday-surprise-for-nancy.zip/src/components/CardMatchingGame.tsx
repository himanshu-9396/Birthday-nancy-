import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, Clipboard, RotateCcw } from 'lucide-react';

interface CardMatchingGameProps {
  onBack: () => void;
  onPastePassword: (password: string) => void;
}

interface Card {
  id: number;
  emoji: string;
  isFlipped: boolean;
  isMatched: boolean;
}

const EMOJIS = ['💖', '💕', '🌷', '🧸', '🎀', '✨', '🦋', '🌸'];

const MATCH_MESSAGES = [
  'So pretty! 🌸',
  'Keep going princess 👑',
  'Almost there 💖',
  'You\'re amazing ✨',
  'One more match! 🎀',
];

export default function CardMatchingGame({ onBack, onPastePassword }: CardMatchingGameProps) {
  const [cards, setCards] = useState<Card[]>([]);
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [matchMessage, setMatchMessage] = useState('');
  const [isWon, setIsWon] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);

  // Initialize and shuffle cards
  const initGame = () => {
    const list = [...EMOJIS, ...EMOJIS]
      .map((emoji, index) => ({
        id: index,
        emoji,
        isFlipped: false,
        isMatched: false,
      }))
      .sort(() => Math.random() - 0.5);
    setCards(list);
    setSelectedCards([]);
    setIsWon(false);
    setShowCelebration(false);
    setMatchMessage('');
  };

  useEffect(() => {
    initGame();
  }, []);

  const handleCardClick = (id: number) => {
    // Prevent clicking if busy or already flipped/matched
    if (selectedCards.length >= 2) return;
    const clickedCard = cards.find((c) => c.id === id);
    if (!clickedCard || clickedCard.isFlipped || clickedCard.isMatched) return;

    // Flip card
    const updatedCards = cards.map((c) => (c.id === id ? { ...c, isFlipped: true } : c));
    setCards(updatedCards);

    const nextSelected = [...selectedCards, id];
    setSelectedCards(nextSelected);

    if (nextSelected.length === 2) {
      const [firstId, secondId] = nextSelected;
      const firstCard = cards.find((c) => c.id === firstId);
      const secondCard = cards.find((c) => c.id === secondId);

      if (firstCard && secondCard) {
        if (firstCard.emoji === secondCard.emoji) {
          // It's a match!
          setTimeout(() => {
            setCards((prev) =>
              prev.map((c) =>
                c.id === firstId || c.id === secondId ? { ...c, isMatched: true } : c
              )
            );
            setSelectedCards([]);

            // Choose a random feedback message
            const randomMsg = MATCH_MESSAGES[Math.floor(Math.random() * MATCH_MESSAGES.length)];
            setMatchMessage(randomMsg);
            setTimeout(() => setMatchMessage(''), 1500);
          }, 300);
        } else {
          // Not a match, flip back
          setTimeout(() => {
            setCards((prev) =>
              prev.map((c) =>
                c.id === firstId || c.id === secondId ? { ...c, isFlipped: false } : c
              )
            );
            setSelectedCards([]);
          }, 1000);
        }
      }
    }
  };

  // Check for victory
  useEffect(() => {
    if (cards.length > 0 && cards.every((c) => c.isMatched)) {
      setIsWon(true);
      setTimeout(() => {
        setShowCelebration(true);
      }, 500);
    }
  }, [cards]);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none py-8">
      <AnimatePresence mode="wait">
        {!showCelebration ? (
          <motion.div
            key="game-board"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="max-w-md w-full p-6 md:p-8 rounded-3xl bg-brand-cream/95 border-2 border-brand-grey/85 shadow-[0_22px_60px_rgba(92,75,64,0.12)] flex flex-col items-center gap-6"
          >
            <div>
              <h2 className="font-royal text-xl font-bold text-brand-brown tracking-widest uppercase">
                🎀 Match Hearts 🎀
              </h2>
              <p className="font-content text-base text-brand-brown/80 mt-1 leading-relaxed">
                Match all the cute emoji secrets to reveal the royal password 💖
              </p>
            </div>

            {/* Match Feedbacks */}
            <div className="h-6 flex items-center justify-center">
              <AnimatePresence>
                {matchMessage && (
                  <motion.p
                    initial={{ opacity: 0, y: -10, scale: 0.8 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="text-brand-brown font-extrabold text-xs tracking-widest uppercase bg-white px-3 py-1 rounded-full border border-brand-grey"
                  >
                    {matchMessage}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-4 gap-3 w-full aspect-square" id="matching-grid">
              {cards.map((card) => {
                const isOpen = card.isFlipped || card.isMatched;
                return (
                  <div
                    key={card.id}
                    onClick={() => handleCardClick(card.id)}
                    className="relative cursor-pointer aspect-square rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                    id={`card-${card.id}`}
                  >
                    <AnimatePresence initial={false}>
                      {!isOpen ? (
                        <motion.div
                          key="back"
                          initial={{ rotateY: 180 }}
                          animate={{ rotateY: 0 }}
                          exit={{ rotateY: 180 }}
                          transition={{ duration: 0.3 }}
                          className="absolute inset-0 bg-white hover:bg-[#eae7e2] border-2 border-brand-grey flex items-center justify-center rounded-2xl p-2.5 shadow-sm text-brand-brown/75 relative"
                        >
                          {/* Exquisite custom line art border & elegant center star design */}
                          <div className="absolute inset-1.5 border border-brand-grey/50 rounded-xl pointer-events-none" />
                          <div className="relative flex flex-col items-center justify-center w-full h-full pointer-events-none">
                            <svg className="w-8 h-8 animate-[spin_40s_infinite_linear]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round">
                              {/* Central artistic mandala */}
                              <circle cx="12" cy="12" r="2.5" fill="currentColor" className="opacity-10" />
                              <circle cx="12" cy="12" r="6.5" strokeDasharray="2 2" />
                              <path d="M12 2 Q12 12 12 22" />
                              <path d="M2 12 Q12 12 22 12" />
                              <path d="M5 5 L19 19" />
                              <path d="M5 19 L19 5" />
                              <path d="M12 6 C10 10, 14 10, 12 18 C10 14, 14 14, 12 6" />
                              <path d="M6 12 C10 10, 10 14, 18 12 C14 10, 14 14, 6 12" />
                            </svg>
                          </div>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="front"
                          initial={{ rotateY: -180 }}
                          animate={{ rotateY: 0 }}
                          exit={{ rotateY: -180 }}
                          transition={{ duration: 0.3 }}
                          className="absolute inset-0 bg-brand-cream border-2 border-brand-brown/40 flex items-center justify-center rounded-2xl text-2xl md:text-3xl shadow-inner text-brand-brown"
                        >
                          {card.emoji}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>

            <div className="flex gap-4 w-full">
              <button
                id="btn-back-to-password"
                onClick={onBack}
                className="flex-1 py-3 px-4 rounded-xl border-2 border-brand-grey/80 bg-white hover:bg-[#eae7e2] text-brand-brown font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-1 cursor-pointer shadow-sm"
              >
                <ChevronLeft size={16} /> Back
              </button>
              <button
                id="btn-reset-game"
                onClick={initGame}
                className="py-3 px-4 rounded-xl border-2 border-brand-grey/80 bg-white hover:bg-[#eae7e2] text-brand-brown font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-1 cursor-pointer shadow-sm"
              >
                <RotateCcw size={16} /> Restart
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="game-success"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="max-w-md w-full p-8 rounded-3xl bg-brand-cream/95 border-2 border-brand-grey/85 shadow-[0_22px_60px_rgba(92,75,64,0.12)] flex flex-col items-center gap-6"
          >
            {/* Sparkly overlay / decorative details */}
            <div className="space-y-2">
              <span className="text-5xl">👑🧸🌟</span>
              <h2 className="font-royal text-2xl md:text-3xl font-black text-brand-brown leading-tight tracking-wide uppercase">
                🎉 Congratulations Nancy 🎉
              </h2>
            </div>

            <p className="font-content text-base sm:text-lg text-brand-brown/80 leading-relaxed max-w-xs">
              You match hearts perfectly! Here is your royal access key:
            </p>

            <div className="w-full py-4 px-6 rounded-2xl bg-white border-2 border-brand-grey flex flex-col items-center gap-1 shadow-inner relative">
              <span className="text-xs uppercase font-sans tracking-widest text-[#5C4B40]/70 font-semibold">
                Your Golden Password Is:
              </span>
              <span className="text-xl sm:text-2xl font-royal font-black text-brand-brown tracking-widest">
                4 JUNE 💖
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 w-full">
              <button
                id="btn-back-to-input"
                onClick={onBack}
                className="flex-1 py-3 px-4 rounded-xl border-2 border-brand-grey/80 bg-white hover:bg-[#eae7e2] text-brand-brown font-bold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-1 cursor-pointer order-2 sm:order-1 shadow-sm"
              >
                <ChevronLeft size={16} /> Back
              </button>
              <button
                id="btn-paste-password"
                onClick={() => onPastePassword('4 JUNE')}
                className="flex-[2] py-3 px-5 rounded-xl bg-brand-brown hover:bg-[#4A3D35] text-brand-cream font-bold text-xs uppercase tracking-widest shadow-[0_6px_20px_rgba(92,75,64,0.25)] transition-all flex items-center justify-center gap-2 cursor-pointer order-1 sm:order-2 border border-brand-brown"
              >
                <Clipboard size={16} /> Paste Password & Enter
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
