import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { playBirthdaySong, stopBirthdaySong, speakBirthdayWish } from '../utils/audio';
import { Gift, Award } from 'lucide-react';

interface CakeCuttingProps {
  onNext: () => void;
}

interface Balloon {
  id: number;
  x: number;
  color: string;
  delay: number;
  size: number;
}

const BALLOON_COLORS = ['#f43f5e', '#ec4899', '#d946ef', '#a855f7', '#3b82f6', '#10b981', '#f59e0b'];

export default function CakeCutting({ onNext }: CakeCuttingProps) {
  const [isCut, setIsCut] = useState(false);
  const [isAnimateKnife, setIsAnimateKnife] = useState(false);
  const [candlesLit, setCandlesLit] = useState(true);
  const [balloons, setBalloons] = useState<Balloon[]>([]);
  const [songPlaying, setSongPlaying] = useState(false);
  const [celebrateText, setCelebrateText] = useState(false);

  // Stop song on unmount
  useEffect(() => {
    return () => {
      stopBirthdaySong();
    };
  }, []);

  const handleCakeClick = () => {
    if (isCut || isAnimateKnife) return;

    // Trigger Knife Cutting motion first
    setIsAnimateKnife(true)

    setTimeout(() => {
      // Actually cut the cake and trigger firework particles & singing
      setIsCut(true);
      setCandlesLit(false); // candles are blown/out during cutting
      setIsAnimateKnife(false);
      setCelebrateText(true);

      // Play Synthesized Birthday song
      playBirthdaySong(undefined, () => {
        setSongPlaying(false);
      });
      setSongPlaying(true);

      // Say "Happy Birthday Nancy" using Web Speech API
      speakBirthdayWish();

      // Launch floating balloons
      launchBalloons();
    }, 1200);
  };

  const launchBalloons = () => {
    const list: Balloon[] = [];
    for (let i = 0; i < 20; i++) {
      list.push({
        id: i,
        x: 10 + Math.random() * 80, // % from left
        color: BALLOON_COLORS[Math.floor(Math.random() * BALLOON_COLORS.length)],
        delay: Math.random() * 4,
        size: 30 + Math.random() * 25,
      });
    }
    setBalloons(list);
  };

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none py-10 overflow-hidden">
      
      {/* Balloon Release Layer */}
      <div className="absolute inset-x-0 bottom-0 top-0 pointer-events-none overflow-hidden z-10 w-full h-full">
        <AnimatePresence>
          {balloons.map((b) => (
            <motion.div
              key={b.id}
              initial={{ y: '110vh', x: `${b.x}vw`, opacity: 0.95 }}
              animate={{ 
                y: '-20vh', 
                x: [`${b.x}vw`, `${b.x + (Math.random() * 10 - 5)}vw`, `${b.x}vw`],
                opacity: 0 
              }}
              transition={{ 
                duration: 6 + Math.random() * 4, 
                delay: b.delay,
                ease: 'easeOut'
              }}
              className="absolute rounded-full shadow-[inset_-5px_-5px_15px_rgba(0,0,0,0.15)] flex flex-col items-center"
              style={{
                width: b.size,
                height: b.size * 1.25,
                backgroundColor: b.color,
              }}
            >
              {/* String attachment */}
              <div className="w-1 h-3 bg-white/40 absolute -bottom-1" />
              <div className="w-0.5 h-16 bg-white/20 absolute -bottom-16" />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="max-w-md w-full flex flex-col items-center gap-8 relative z-20">
        
        {/* Instruction or Celebration Headers */}
        <div className="min-h-[5.5rem] flex flex-col items-center justify-center">
          <AnimatePresence mode="wait">
            {!celebrateText ? (
              <motion.div
                key="before-cut"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-1.5 flex flex-col items-center"
              >
                <h2 className="font-royal text-xl sm:text-2xl font-bold text-brand-brown tracking-widest uppercase">
                  🎂 The Royal Cake Cutting Ceremony 🎂
                </h2>
                <p className="font-content text-base sm:text-lg text-brand-brown font-extrabold tracking-wide animate-pulse bg-white px-4 py-1.5 rounded-full border border-brand-grey/80">
                  Tap the cake to cut it 🔪
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="after-cut"
                initial={{ opacity: 0, scale: 0.8, y: -20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ type: 'spring', stiffness: 200, damping: 10 }}
                className="space-y-1"
              >
                <h2 className="font-royal text-2xl sm:text-3.5xl font-black text-brand-brown tracking-widest uppercase">
                  🎂 Happy Birthday Nancy 🎂
                </h2>
                <p className="font-content text-lg text-brand-brown/70 font-bold tracking-wide">
                  🎵 Happy Birthday To You... 🎵
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Interactive Cake and Knife Stage - Magnified size */}
        <div 
          onClick={handleCakeClick}
          className={`${!isCut ? 'cursor-pointer hover:scale-[1.05]' : ''} relative w-80 h-80 sm:w-96 sm:h-96 md:w-[410px] md:h-[410px] flex items-center justify-center transition-transform duration-300`}
          id="cake-cutting-stage"
        >
          {/* Animated floating knife (Page 7 Specific Interaction) */}
          <AnimatePresence>
            {isAnimateKnife && (
              <motion.div
                key="knife"
                initial={{ x: 70, y: -90, rotate: -45, opacity: 0 }}
                animate={{ x: 0, y: -50, rotate: -15, opacity: 1 }}
                exit={{ x: -10, y: 50, rotate: 10, opacity: 0 }}
                transition={{ duration: 1.0, ease: 'easeInOut' }}
                className="absolute z-30 text-6xl font-bold"
                id="cutting-knife-element"
              >
                🔪
              </motion.div>
            )}
          </AnimatePresence>

          {/* SVG Cakes split animation depending on isCut */}
          <div className="w-full h-full flex items-center justify-center">
            <svg viewBox="0 0 200 200" className="w-full h-full">
              
              {/* Left Segment of the Cake */}
              <motion.g
                animate={isCut ? { x: -25, y: 12, rotate: -4 } : { x: 0, y: 0, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 90, damping: 14 }}
                className="origin-bottom-left"
              >
                {/* Cake base layer left */}
                <path d="M 100 150 L 30 150 Q 30 130 100 130 Z" fill="#db2777" /> {/* Dense Dark Pink raspberry frosting */}
                <path d="M 100 130 L 30 130 Q 30 110 100 110 Z" fill="#4a2c11" /> {/* Moist Premium Chocolate center layer */}
                <path d="M 100 110 L 40 110 Q 40 95 100 95 Z" fill="#9d174d" /> {/* Deep Dark Strawberry upper glaze */}
                
                {/* Cream drips left */}
                <path d="M 40 110 Q 50 122 60 110 Q 70 122 80 110 Q 90 122 100 113" stroke="#ec4899" strokeWidth="3" strokeLinecap="round" fill="none" />

                {/* Candles Lit left */}
                <g>
                  {/* Candle 1 */}
                  <rect x="55" y="65" width="6" height="30" fill="#a855f7" rx="2" />
                  <rect x="55" y="70" width="6" height="5" fill="#fde047" />
                  <line x1="58" y1="65" x2="58" y2="58" stroke="#374151" strokeWidth="1.5" />
                  {candlesLit && (
                    <motion.path
                      animate={{ scale: [1, 1.2, 1], y: [0, -1, 0] }}
                      transition={{ repeat: Infinity, duration: 0.6 }}
                      d="M 58 58 Q 54 53 58 48 Q 62 53 58 58 Z"
                      fill="#fbbf24"
                      className="drop-shadow-[0_0_5px_#f59e0b]"
                    />
                  )}
                </g>
              </motion.g>

              {/* Right Segment of the Cake */}
              <motion.g
                animate={isCut ? { x: 25, y: 12, rotate: 4 } : { x: 0, y: 0, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 90, damping: 14 }}
                className="origin-bottom-right"
              >
                {/* Cake base layer right */}
                <path d="M 100 150 L 170 150 Q 170 130 100 130 Z" fill="#db2777" /> {/* Dense Dark Pink raspberry frosting */}
                <path d="M 100 130 L 170 130 Q 170 110 100 110 Z" fill="#4a2c11" /> {/* Moist Premium Chocolate center layer */}
                <path d="M 100 110 L 160 110 Q 160 95 100 95 Z" fill="#9d174d" /> {/* Deep Dark Strawberry upper glaze */}

                {/* Cream drips right */}
                <path d="M 100 113 Q 110 122 120 110 Q 130 122 140 110 Q 150 122 160 110" stroke="#ec4899" strokeWidth="3" strokeLinecap="round" fill="none" />

                {/* Strawberry cream decorations top */}
                <circle cx="115" cy="94" r="5.5" fill="#e11d48" />
                <circle cx="138" cy="99" r="5.5" fill="#e11d48" />

                {/* Candles Lit right */}
                <g>
                  {/* Candle 2 */}
                  <rect x="135" y="65" width="6" height="30" fill="#3b82f6" rx="2" />
                  <rect x="135" y="70" width="6" height="5" fill="#60a5fa" />
                  <line x1="138" y1="65" x2="138" y2="58" stroke="#374151" strokeWidth="1.5" />
                  {candlesLit && (
                    <motion.path
                      animate={{ scale: [1, 1.2, 1], y: [0, -1, 0] }}
                      transition={{ repeat: Infinity, duration: 0.7 }}
                      d="M 138 58 Q 134 53 138 48 Q 142 53 138 58 Z"
                      fill="#fbbf24"
                      className="drop-shadow-[0_0_5px_#f59e0b]"
                    />
                  )}
                </g>
              </motion.g>

              {/* Central Candle (splittable, we place it exactly on left side for convenience or hide during split) */}
              <motion.g
                animate={isCut ? { opacity: 0, scale: 0 } : { opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <rect x="97" y="55" width="6" height="40" fill="#10b981" rx="2" />
                <rect x="97" y="60" width="6" height="6" fill="#6ee7b7" />
                <line x1="100" y1="55" x2="100" y2="48" stroke="#374151" strokeWidth="1.5" />
                {candlesLit && (
                  <motion.path
                    animate={{ scale: [1, 1.3, 1], y: [0, -1.5, 0] }}
                    transition={{ repeat: Infinity, duration: 0.5 }}
                    d="M 100 48 Q 96 42 100 37 Q 104 42 100 48 Z"
                    fill="#fbbf24"
                    className="drop-shadow-[0_0_6px_#f59e0b]"
                  />
                )}
              </motion.g>

              {/* Sparkles on Plate bottom */}
              <ellipse cx="100" cy="155" rx="75" ry="10" fill="rgba(60,50,40,0.06)" stroke="rgba(60,50,40,0.12)" strokeWidth="1.5" />
            </svg>
          </div>

          {/* Sparkles appearing during cuts */}
          {isCut && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              {[...Array(12)].map((_, i) => (
                <motion.span
                  key={i}
                  initial={{ opacity: 1, scale: 0.5, x: 0, y: 0 }}
                  animate={{ 
                    opacity: [1, 0], 
                    scale: [0.5, 1.5, 0.2],
                    x: (Math.random() - 0.5) * 160, 
                    y: (Math.random() - 0.5) * 160 
                  }}
                  transition={{ duration: 1.5, delay: Math.random() * 0.2 }}
                  className="absolute text-xl"
                >
                  {['✨', '💥', '🎉', '🌸', '💖', '🍭'][i % 6]}
                </motion.span>
              ))}
            </div>
          )}
        </div>

        {/* Transition Button to Gift */}
        <AnimatePresence>
          {isCut && (
            <motion.button
              id="cake-next-btn"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5 }}
              whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
              whileTap={{ scale: 0.97 }}
              onClick={() => {
                stopBirthdaySong();
                onNext();
              }}
              className="px-8 py-3.5 rounded-xl bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest shadow-[0_6px_20px_rgba(92,75,64,0.25)] flex items-center gap-2 border border-brand-brown cursor-pointer transition-colors"
            >
              🎁 Let's Grab Your Gift! 🎁
            </motion.button>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
