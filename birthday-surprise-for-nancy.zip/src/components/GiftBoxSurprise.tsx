import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Heart, Gift } from 'lucide-react';

interface GiftBoxSurpriseProps {
  onNext: () => void;
}

export default function GiftBoxSurprise({ onNext }: GiftBoxSurpriseProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const handleOpenGift = () => {
    if (isOpen || busy) return;
    setBusy(true);
    setIsOpen(true);
    setBusy(false);
  };

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none py-10 overflow-hidden">
      <div className="max-w-md w-full flex flex-col items-center gap-10">
        
        {/* Surprise Header text */}
        <div className="min-h-[4rem] flex flex-col items-center justify-center">
          <AnimatePresence mode="wait">
            {!isOpen ? (
              <motion.div
                key="closed-header"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-1.5"
              >
                <h2 className="font-royal text-xl sm:text-2xl font-bold text-brand-brown tracking-widest uppercase animate-pulse">
                  🎁 Royal Gift Box For Princess Nancy 🎁
                </h2>
                <p className="font-content text-base sm:text-lg text-brand-brown/80 font-semibold">
                  Tapping the magical parcel reveals its truth!
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="open-header"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-1.5"
              >
                <h2 className="font-royal text-2xl sm:text-3.5xl font-black text-brand-brown tracking-widest uppercase">
                  💖 Unveiled For You 💖
                </h2>
                <p className="font-content text-base sm:text-lg text-brand-[#5C4B40]/85 font-semibold">
                  The universe is sending endless love today...
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Gift Box animation stage */}
        <div className="relative w-64 h-64 flex items-center justify-center" id="gift-box-stage">

          {/* Ambient golden radial backglow */}
          <div className="absolute inset-0 bg-radial from-amber-400/25 to-transparent rounded-full blur-2xl animate-pulse" />

          {/* The open gift container elements */}
          <div className="relative w-48 h-48 flex items-center justify-center">
            
            <AnimatePresence>
              {!isOpen ? (
                // Closed Box Wrapper
                <motion.div
                  key="box-closed"
                  onClick={handleOpenGift}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full h-full flex flex-col items-center justify-end relative cursor-pointer"
                  id="gift-box-closed-element"
                >
                  {/* Glowing lid */}
                  <motion.div
                    animate={{ y: [0, -3, 0] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                    className="w-[110%] h-10 bg-gradient-to-r from-pink-500 to-rose-400 rounded-t-lg shadow-md z-10 flex items-center justify-center relative border-b-2 border-pink-600/30"
                  >
                    {/* Ribbon Crossbow center lid */}
                    <div className="absolute w-6 h-full bg-amber-300 left-1/2 -ml-3" />
                    {/* Cute puffy bowknot topper */}
                    <div className="absolute -top-6 w-12 h-6 bg-amber-400 rounded-full border-2 border-amber-500/50 flex justify-around">
                      <div className="w-4 h-4 rounded-full bg-amber-300" />
                      <div className="w-4 h-4 rounded-full bg-amber-300" />
                    </div>
                  </motion.div>

                  {/* Box body */}
                  <div className="w-full h-28 bg-gradient-to-br from-pink-600 to-rose-500 rounded-b-xl shadow-xl border border-pink-400/20 relative flex items-center justify-center">
                    {/* Ribbon cross horizontally and vertically */}
                    <div className="absolute w-6 h-full bg-amber-300 left-1/2 -ml-3" />
                    <Gift size={48} className="text-white/20 relative z-10" />
                  </div>
                </motion.div>
              ) : (
                // Open Box Wrapper
                <motion.div
                  key="box-open"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="w-full h-full flex flex-col items-center justify-end relative"
                  id="gift-box-open-element"
                >
                  {/* Floating Box Lid flew off upward */}
                  <motion.div
                    initial={{ y: 0, x: 0, rotate: 0 }}
                    animate={{ y: -130, x: 50, rotate: 45, opacity: 0 }}
                    transition={{ duration: 1.2, ease: 'easeOut' }}
                    className="absolute w-[110%] h-10 bg-gradient-to-r from-pink-500 to-rose-400 rounded-t-lg z-10"
                  >
                    <div className="absolute w-6 h-full bg-amber-300 left-1/2 -ml-3" />
                  </motion.div>

                  {/* Inside Message / Big Floating Heart! */}
                  <motion.div
                    initial={{ scale: 0.2, y: 15, opacity: 0 }}
                    animate={{ scale: 1, y: -45, opacity: 1 }}
                    transition={{ type: 'spring', stiffness: 200, damping: 15, delay: 0.3 }}
                    className="absolute z-20 w-56 p-5 rounded-2xl bg-brand-cream/95 border-2 border-brand-grey flex flex-col items-center gap-2 shadow-[0_12px_36px_rgba(92,75,64,0.12)]"
                  >
                    <motion.div
                      animate={{ scale: [1, 1.15, 1] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                    >
                      <Heart size={36} fill="#fbbf24" className="text-amber-500 drop-shadow-[0_0_8px_rgba(245,158,11,0.3)]" />
                    </motion.div>
                    
                    <p className="font-content italic text-base text-brand-brown font-extrabold leading-relaxed text-center">
                      "The best gift today is seeing you smile ❤️"
                    </p>
                  </motion.div>

                  {/* Empty Box Body sitting down */}
                  <div className="w-full h-28 bg-gradient-to-br from-pink-800 to-rose-700 rounded-b-xl shadow-inner border border-pink-900/40 relative">
                    <div className="absolute w-6 h-full bg-amber-500 left-1/2 -ml-3" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Sparkle explosion on open */}
            {isOpen && (
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                {[...Array(15)].map((_, i) => (
                  <motion.span
                    key={i}
                    initial={{ opacity: 1, scale: 0.5, x: 0, y: -20 }}
                    animate={{ 
                      opacity: [1, 0], 
                      scale: [0.5, 1.4, 0.2],
                      x: (Math.random() - 0.5) * 180, 
                      y: -40 - Math.random() * 120 
                    }}
                    transition={{ duration: 1.8, delay: Math.random() * 0.15 }}
                    className="absolute text-xl"
                  >
                    {['🌸', '👑', '🕊️', '✨', '💖', '💐'][i % 6]}
                  </motion.span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Action Button to Open or Transition */}
        <div className="h-14 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {!isOpen ? (
              <motion.button
                id="btn-open-gift-action"
                key="open-btn"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
                whileTap={{ scale: 0.97 }}
                onClick={handleOpenGift}
                className="px-8 py-3 bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest rounded-xl font-sans shadow-md border border-brand-brown cursor-pointer transition-colors"
              >
                🎁 Open Gift 🎁
              </motion.button>
            ) : (
              <motion.button
                id="gift-next-btn"
                key="next-btn"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
                whileTap={{ scale: 0.97 }}
                onClick={onNext}
                className="px-8 py-3.5 rounded-xl bg-brand-brown text-brand-cream font-bold text-xs uppercase tracking-widest shadow-[0_6px_20px_rgba(92,75,64,0.25)] flex items-center gap-2 border border-brand-brown cursor-pointer transition-colors"
              >
                🌟 Make Your Wishes 🌟
              </motion.button>
            )}
          </AnimatePresence>
        </div>

      </div>
    </div>
  );
}
