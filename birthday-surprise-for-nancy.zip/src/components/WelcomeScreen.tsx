import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface WelcomeScreenProps {
  onNext: () => void;
}

export default function WelcomeScreen({ onNext }: WelcomeScreenProps) {
  const [showSub, setShowSub] = useState(false);
  const [typedText, setTypedText] = useState('');
  const fullText = "HAPPY BIRTHDAY NANCY";

  // Typewriter effect for "HAPPY BIRTHDAY NANCY"
  useEffect(() => {
    let index = 0;
    setTypedText('');
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setTypedText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(timer);
      }
    }, 130);

    // After typing is almost complete, show subtitle and button
    const subTimer = setTimeout(() => {
      setShowSub(true);
    }, 2800);

    return () => {
      clearInterval(timer);
      clearTimeout(subTimer);
    };
  }, []);

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen w-full px-4 text-center select-none overflow-hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
        className="max-w-xl w-full px-8 py-12 md:py-16 rounded-3xl bg-brand-cream/95 border-2 border-brand-grey/85 shadow-[0_22px_60px_rgba(92,75,64,0.12)] flex flex-col items-center gap-6 md:gap-8 mx-auto"
        id="welcome-card"
      >
        <motion.div
          animate={{ 
            scale: [1, 1.02, 1],
          }}
          transition={{ 
            repeat: Infinity, 
            duration: 6, 
            ease: "easeInOut" 
          }}
          className="relative inline-block w-full"
        >
          {/* Subtle warm amber glow behind the elegant title */}
          <div className="absolute -inset-1 rounded-full bg-amber-500/5 blur-xl animate-pulse" />
          
          <h1 className="relative font-royal text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black text-brand-brown tracking-widest leading-none px-4 py-3 min-h-[5.5rem] md:min-h-[7rem]">
            🎉 {typedText}
            <span className="animate-pulse font-sans font-light text-brand-grey">|</span> 🎉
          </h1>
        </motion.div>

        <div className="h-12 flex items-center justify-center">
          <AnimatePresence>
            {showSub && (
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8 }}
                className="font-content italic text-lg sm:text-xl font-semibold tracking-wide text-brand-brown/80"
              >
                ✨ A Special Surprise Awaits You ✨
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        <motion.button
          id="btn-open-surprise"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={showSub ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.95 }}
          whileHover={{ scale: 1.03, backgroundColor: '#4A3D35' }}
          whileTap={{ scale: 0.97 }}
          transition={{ type: 'spring', stiffness: 350, damping: 22 }}
          onClick={onNext}
          className={`${
            showSub ? 'pointer-events-auto cursor-pointer' : 'pointer-events-none'
          } mt-4 px-8 py-3.5 rounded-xl bg-brand-brown text-brand-cream font-bold text-base shadow-[0_6px_20px_rgba(92,75,64,0.25)] flex items-center gap-2 border border-brand-brown/80 font-sans tracking-widest transition-all`}
        >
          ❤️ OPEN YOUR SURPRISE ❤️
        </motion.button>
      </motion.div>
    </div>
  );
}
