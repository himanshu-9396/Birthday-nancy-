/**
 * Web Audio API Music Box Synthesizer for "Happy Birthday" melody
 */

interface Note {
  pitch: string;
  freq: number;
  duration: number; // in seconds
}

const melody: Note[] = [
  { pitch: 'C4', freq: 261.63, duration: 0.35 },
  { pitch: 'C4', freq: 261.63, duration: 0.15 },
  { pitch: 'D4', freq: 293.66, duration: 0.5 },
  { pitch: 'C4', freq: 261.63, duration: 0.5 },
  { pitch: 'F4', freq: 349.23, duration: 0.5 },
  { pitch: 'E4', freq: 329.63, duration: 1.0 },

  { pitch: 'C4', freq: 261.63, duration: 0.35 },
  { pitch: 'C4', freq: 261.63, duration: 0.15 },
  { pitch: 'D4', freq: 293.66, duration: 0.5 },
  { pitch: 'C4', freq: 261.63, duration: 0.5 },
  { pitch: 'G4', freq: 392.00, duration: 0.5 },
  { pitch: 'F4', freq: 349.23, duration: 1.0 },

  { pitch: 'C4', freq: 261.63, duration: 0.35 },
  { pitch: 'C4', freq: 261.63, duration: 0.15 },
  { pitch: 'C5', freq: 523.25, duration: 0.5 },
  { pitch: 'A4', freq: 440.00, duration: 0.5 },
  { pitch: 'F4', freq: 349.23, duration: 0.5 },
  { pitch: 'E4', freq: 329.63, duration: 0.5 },
  { pitch: 'D4', freq: 293.66, duration: 0.75 },

  { pitch: 'Bb4', freq: 466.16, duration: 0.35 },
  { pitch: 'Bb4', freq: 466.16, duration: 0.15 },
  { pitch: 'A4', freq: 440.00, duration: 0.5 },
  { pitch: 'F4', freq: 349.23, duration: 0.5 },
  { pitch: 'G4', freq: 392.00, duration: 0.5 },
  { pitch: 'F4', freq: 349.23, duration: 1.2 },
];

let audioCtx: AudioContext | null = null;
let activeOscillators: { osc: OscillatorNode; gain: GainNode }[] = [];
let noteTimeout: any = null;

function getAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playBirthdaySong(onNotePlay?: (noteIndex: number) => void, onComplete?: () => void) {
  stopBirthdaySong();
  const ctx = getAudioContext();
  let startTime = ctx.currentTime + 0.1;

  melody.forEach((note, index) => {
    // Shedule oscillators
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();

    // Use a lovely bell/music-box chime tone
    // Combination of sine and triangle wave
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(note.freq, startTime);

    // Dynamic clean envelope for chime sound
    gainNode.gain.setValueAtTime(0, startTime);
    gainNode.gain.linearRampToValueAtTime(0.25, startTime + 0.05); // attack
    gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + note.duration - 0.02); // decay/release

    osc.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + note.duration);

    activeOscillators.push({ osc, gain: gainNode });

    const delayMs = (startTime - ctx.currentTime) * 1000;
    setTimeout(() => {
      if (onNotePlay) onNotePlay(index);
    }, delayMs);

    startTime += note.duration + 0.08; // small gap between notes
  });

  const totalDurationMs = (startTime - ctx.currentTime) * 1000;
  noteTimeout = setTimeout(() => {
    if (onComplete) onComplete();
  }, totalDurationMs);
}

export function stopBirthdaySong() {
  if (noteTimeout) {
    clearTimeout(noteTimeout);
    noteTimeout = null;
  }
  activeOscillators.forEach(({ osc, gain }) => {
    try {
      osc.stop();
    } catch (e) {}
    try {
      osc.disconnect();
      gain.disconnect();
    } catch (e) {}
  });
  activeOscillators = [];
}

export function speakBirthdayWish() {
  if ('speechSynthesis' in window) {
    // Cancel prior speech first
    window.speechSynthesis.cancel();
    
    const text = "Happy Birthday Nancy! You make the world so beautiful.";
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Choose a sweet, higher pitched, gentle voice if available
    const voices = window.speechSynthesis.getVoices();
    // Try to find a nice English voice (female if possible)
    const femaleVoice = voices.find(v => 
      v.lang.startsWith('en') && 
      (v.name.toLowerCase().includes('google') || v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('zira'))
    );
    if (femaleVoice) {
      utterance.voice = femaleVoice;
    }
    
    utterance.pitch = 1.2; // Slightly higher pitch for a cute, happy tone
    utterance.rate = 0.9;  // Slightly slower rate for a warm friendly tone
    utterance.volume = 1.0;
    
    window.speechSynthesis.speak(utterance);
  }
}
